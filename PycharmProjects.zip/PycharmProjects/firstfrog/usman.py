# import flask

print("Hello Muawa is back 6")
a = 2
b = 4
c = a + b
print(c)

x = 5
y = 4
z = x + y
print(z)


print("Hello Command ")