

import qrcode as qr

img = qr.make("https://portal.ucp.edu.pk/course_Annoucements/63581")
img.save("google.png")
