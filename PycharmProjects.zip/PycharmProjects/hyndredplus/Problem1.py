"""python practice problem # 1
Your age in 2090
Take input from user age or year of birth"""

yearage=int(input("What is your age:"))
if yearage<125:
    isAge=True
elif yearage>1900:
    isYear=True
else:
    print("SomeThing is Wrong with your age/year")

print(f"")














