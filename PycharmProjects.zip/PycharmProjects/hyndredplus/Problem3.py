lst=input("Enter your list: ")
print(lst)

lst=lst[::-1]
print(lst)