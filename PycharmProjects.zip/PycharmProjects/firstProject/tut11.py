# dictionary = {"Easy": "Asaan", "tough": "Muskil", "Game": "Kheal", "fruit": "phall"}
# print("Enter Word: ")
# word = input()
# print(dictionary[word])

sett = set({2, 3, 4, 5, })
sett = set(list)
print(sett)
# print(type(sett))
#
# listt = [2, 3, 4]
# sett = set(listt)
# print(type(sett))
# s = set()
# s.add(1)
# s.add(1)
# s.add(2)
# s1 = s.union({1, 2})
# s1 = s.intersection({1, 2, 3})
# #  s1.disjoint  # s1.remove(2)
# print(s1)
