n = int(input("Enter a star number: "))
a = 1
while a <= n:
    print("*" * a)
    a = a + 1

a = 1
while a <= n:
    print("*" * n)
    n = n - 1
# n = n - 1
