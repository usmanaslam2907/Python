access private attribues using
__variable private
a=Employee()
print(a._Employee__name)  #called mangling

_variable protected