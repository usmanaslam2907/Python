# Abstaction and encapsulation
# layers of computer as working as a layer  of abstraction like send man on mars so used many computers
# so how to used computer how harddisk work and cpu working so we encapsulate things to use like implementation hide in
#  Encapsulation like hide implementation mangoes kaho gutlia na gino  soo what how the print function work
# abstraction tukroo ma bant dena
#  player class and city class are two separte layer  so encapsule that both layer in encapsule
