a = int(input("Enter a\n"))
b = int(input("Enter b\n"))

"""if a>b: print("a is bigger than b")
else: print(" b is bigger than a")"""

print("a is bigger than b") if a > b else print("b is bigger than a")

print("a is greater then b") if a > b else print("b is greater th")



