# fstring and string format
import math

me = "usman is back from United states"
# ss="this is %s"%me
# print(ss)
you="great"

# fstring>>>fast string f for fast
a=f"this is {me} {you} {3*6} {math.cos(65)} {math.factorial(5)}"
print(a)



