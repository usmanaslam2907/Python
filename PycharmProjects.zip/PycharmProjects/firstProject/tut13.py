# var1 = 2
# var2 = 67
# var3 = int(input("Enter the Number: "))
# if var3 > var2:
#     print("Greater")
# elif var3 == var2:
#     print("Equal")
# else:
#     print("Lesser")


list1 = [3, 6, 9, 11, 13, 17]
if 69 not in list1:
    print("Yes")
"""if 9 in list1:
    print("Yes in the list")
if 67 not in list1:
    print("67 not in list")
    print(13 in list1)
    print(68 in list1)"""
# if 9 in list1:
#     print("yes")

