# dont use file name as module
# Operators in python
"""1.
Arithemetic Operators
 Assignment OPerators
2. Comparision Operators
3. Logical Operators
4. Identify Operators
5. Membership Operator
6. Bitwise Operator"""

"""print("5 + 6 = ", 5 + 6)
print("5 - 6 = ", 5 - 6)
print("5 * 6 = ", 5 * 6)
print("5 ** 6 = ", 5 ** 6)
print("5 // 6 = ", 5 // 6)
print("5 % 6 = ", 5 % 6)

x=5
print(x)
x+=7
print(x)"""

"""i = 8
print(i == 8)
print(i >= 8)
print(i <= 8)
print(i != 8)
"""


"""a=True
b=False
print(a and b)
print(a or b)
print(a is not b)
print(a is  b)
print( a | b)
print( a & b)"""

"""list = [1,3,5,6,7]
print(7 in list)
print(9 in list)
print(32 not in list)"""


"""0 - 00
1 - 01
2 - 10
3 - 11"""





