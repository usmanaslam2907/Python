# solve solider excercise

# is and equal
#   Is  and Equal  ==  and is
#  == value equality   >>>>2 object have same value
#   is -- reference equality>>>> Two reference refer to same object

#   a=[3,4,5]
#   b=a  get true
a=[6,5,"45"]
b=[6,4,"45"]
print(b is a)
print(b == a)
