# import random  module k function use kie like randit and choice and random
import random

number = random.randint(1, 20)
# print(number)

#  module k andar ak or random module
num=random.random()*100 # generate b/w 1-100
# print(num)

# random.choice use for in list
lst =["Geo News","Hum","ARY","PTV","Sports"]
selection=random.choice(lst)
print(selection)