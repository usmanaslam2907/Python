# lamda function and anonymous function
# function  bana b du or nah b bnao
# lamda is one liner functiom
import lambda as lamda

#
# def minus(x, y):
#     return x - y

# new way to make function by using lamda

minus=lambda x,y:x-y
print(minus(9,4))