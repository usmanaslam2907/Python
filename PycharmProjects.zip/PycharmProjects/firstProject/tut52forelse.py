khana=["roti","sabzi","chawal","parata"]
for item in khana:
    if item=="parata":
        print(item)
        break
else:
    print("Your item was not find")
    # print('This loop properly ended') # ya tab chale ga jab when for loop complete their work
