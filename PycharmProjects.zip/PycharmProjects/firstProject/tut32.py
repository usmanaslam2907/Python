import flask
import sklearn

# import pip
import sys
print(sys.path)

from file2 import abc
