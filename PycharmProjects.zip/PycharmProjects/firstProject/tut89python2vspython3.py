# python 2.x and python 3.x
# print statement   in python 2
# print('str')
