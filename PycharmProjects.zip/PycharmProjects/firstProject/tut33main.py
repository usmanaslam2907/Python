# import sklearn


def printhar(string):
    return f"this is usman string that {string}"


def add(num1, num2):
    return num1 + num2


print("game is over")

if __name__ == '__main__':
    print(printhar("Usman"))
    o = add(4, 6)
    print(o)

