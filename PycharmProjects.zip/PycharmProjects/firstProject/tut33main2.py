# import tut33main
# print(tut33main.add(5,5))
# so all functions execute in imported file
import tut33main

c = tut33main.add(5, 5)
print(c)
