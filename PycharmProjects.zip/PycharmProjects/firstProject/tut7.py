variable ="Usman"
print(variable)

variable ="Usman"
print(variable)




"""variable = "Usman"
variable ="usman"
va=2
print(type(variable)
print(t1Wd

print(str(v1)+str(v2))
v1 = 2
v2 = 3
print(type(variable))
# print(v1*v2)
print(str(str(v1)+str(v2)))
var4 = 32
print(var4)"""
"""Type casting
string to int so used int(variable)
str()
int()
float()"""
"""print("Enter Your Age:  ")

age = input()  # input as a string not integer
print("Your current age is: ", age)
print("Your are born in: ", 2022-int(age))  # convert into integer"""
# print("Enter num1")
# n1 = input()
# print("Enter num2: ")
# n2 = input()
# print("Sum is: ", int(n1)+int(n2))

# variable=34
# print(type(32))






