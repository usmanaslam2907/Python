# pass ka matlab kuch nai likha

class Student:
   pass

usman=Student()
zeeshan=Student()

# instance ma variable dena
usman.name="usman"
usman.age=22
usman.regno="L1F19BSSE0153"
usman.subjects=["ML","MAD"]

print(usman.subjects)