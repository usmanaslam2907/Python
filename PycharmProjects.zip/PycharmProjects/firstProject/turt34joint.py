# lst = ["Usman", "Zeeshan", "Javed", "Haroon", "Iqbal"]
# # for items in lst:
# #     print("Items is ", items, "and ", end=" ")
#
# a = " , ".join(lst)
# print(a, "\nother we are superstars")

lst = ["khan", "wains", "lahore"]
# for l1 in lst:
#     print("List 1 is ", l1, " that ", end="     ")
k = " , "
a = k.join(lst)
print(a, "\n other")


lst