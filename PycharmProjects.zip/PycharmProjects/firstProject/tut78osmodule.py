import os
# print(dir(os))
# print(os.getcwd())
# Change directory
# os.chdir("C://")
print(os.getcwd())
# f=open("usman.txt")
# print(os.listdir())
# print(os.listdir("C://Program Files"))
#     Make folder
# os.mkdir("Folder")

#  make folders directories  this k andar that bane ga
# os.makedirs(("this/that"))
# # os.rename("usman.txt","muawa.txt")
# print(os.environ.get("Path"))
# print(os.path.exists("C://"))
# print(os.path.isfile("C://"))