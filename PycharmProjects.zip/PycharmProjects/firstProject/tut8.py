mystr = "usman is a good  boy"

# print(mystr[0:5])  # string slicing 5 is exclude
# print(len(mystr))
# print(mystr[0:5:2])  # 0:u 2:m 4:n 2 ka gap ha umn
# print(mystr[::9])  # uay print
# print(mystr[1:5])   # sman print ho ga
# print(mystr[-2:-6])   #sman print reverse counting so used [::-2]

#  -2 last wale print kare ga or -6 means last sa remove kare ga

"""print(mystr.endswith("boy"))  # print true
print(mystr.count("o"))   # count "o" so o is 3 then print 3"""
"""print(mystr.capitalize())  # first letter capitalize
print(mystr.find("is"))  #  find is loaction"""
"""print(mystr.upper())
print(mystr.lower())
print(mystr.replace("good", "intelligent"))"""

strr = "usman is a good boy"
print(strr.upper())


