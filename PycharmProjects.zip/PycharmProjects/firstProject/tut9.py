# list  append,insert,remove,pop

names = ["usman", "zeeshan", "nisar", "rafey", "waqar", "123", 56]
names=["names","zeehsan"]
numbers = [2, 5, 7, 9, 34]
print(names)
numbers.sort()
numbers.reverse()
print(numbers)
# numbers slicing
"""print(numbers[2:5])  # print 7 5 2
print(len(numbers))
print(min(numbers),max(numbers))"""
"""numbers.append(99)
print(numbers)
numbers.insert(2, 67)
print(numbers)
numbers.remove(99)
numbers.pop()
print(numbers)"""
"""Lists is mutable means we can change lists 
Tuple is immutable means we cannot change tuples"""
# tuple =(1, 2, 3, 4, 5)
# tp=(1,)  # tuple cannot change
# print(tuple)
# print(tp)
# # swap using temp
# a=1
# b=3
# a,b=b,a
# print(a,b)  # swap technique





















