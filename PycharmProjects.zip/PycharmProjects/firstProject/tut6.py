
#please dont use this code
"""multi
ignore
line
now"""

print("Subscribe now the harry channel with\n good intensions ", end=" ")
print("  is working means new line without next line")





print("usmna",end=" ")








